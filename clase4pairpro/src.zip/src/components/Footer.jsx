import React from "react";
import '../styles/footer.css'

function Footer(){
    return(
        <footer>

        </footer>
    )
}

export default Footer;
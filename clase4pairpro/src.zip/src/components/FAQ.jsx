import React from "react";
import '../styles/faq.css'

function Faq(){
    return(
        <div className="faq">
            <p>pregunta 1
                <p> respuesta</p>
            </p>
            <p>pregunta 2
                <p> respuesta</p>
            </p>
        </div>
    )
}
 export default Faq;